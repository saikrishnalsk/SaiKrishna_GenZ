import { Link } from "react-router-dom";
import { Menu } from "lucide-react";
import { useState } from "react";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-2xl font-bold text-primary">SK</Link>
          
          {/* Mobile menu button */}
          <button 
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu className="w-6 h-6" />
          </button>

          {/* Desktop menu */}
          <div className="hidden md:flex gap-8">
            <Link to="/about" className="nav-link">About</Link>
            <Link to="/portfolio" className="nav-link">Portfolio</Link>
            <Link to="/mern-challenge" className="nav-link">100 Days MERN Stack</Link>
            <Link to="/contact" className="nav-link">Contact</Link>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-4">
            <Link to="/about" className="block nav-link">About</Link>
            <Link to="/portfolio" className="block nav-link">Portfolio</Link>
            <Link to="/mern-challenge" className="block nav-link">100 Days MERN Stack</Link>
            <Link to="/contact" className="block nav-link">Contact</Link>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;