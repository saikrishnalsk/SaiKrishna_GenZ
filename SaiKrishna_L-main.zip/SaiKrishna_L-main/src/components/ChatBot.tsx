import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { MessageSquare } from "lucide-react";

interface ChatBotProps {
  startOpen?: boolean;
}

const ChatBot = ({ startOpen = false }: ChatBotProps) => {
  const [isOpen, setIsOpen] = useState(startOpen);
  const [messages, setMessages] = useState<{text: string, sender: 'user' | 'bot'}[]>([]);
  const [input, setInput] = useState("");

  const generateBotResponse = (userMessage: string) => {
    const responses = [
      "That's interesting! Tell me more about your coding journey.",
      "I'm here to help you learn about MERN stack development!",
      "Have you checked out the 100 Days MERN Stack Challenge?",
      "Programming is fun! Keep learning and practicing.",
      "Feel free to ask me anything about web development!",
    ];
    
    // Simple keyword-based responses
    if (userMessage.toLowerCase().includes("mern")) {
      return "MERN stack includes MongoDB, Express.js, React, and Node.js. It's a powerful combination!";
    }
    if (userMessage.toLowerCase().includes("react")) {
      return "React is a fantastic library for building user interfaces. Are you enjoying learning it?";
    }
    if (userMessage.toLowerCase().includes("hello") || userMessage.toLowerCase().includes("hi")) {
      return "Hello! I'm Sai's personal chatbot. How can I help you today?";
    }
    
    // Return random response if no keywords match
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const handleSend = () => {
    if (!input.trim()) return;
    
    setMessages([...messages, { text: input, sender: 'user' }]);
    setInput("");
    
    // Generate bot response
    setTimeout(() => {
      const botResponse = generateBotResponse(input);
      setMessages(prev => [...prev, { 
        text: botResponse, 
        sender: 'bot' 
      }]);
    }, 1000);
  };

  return (
    <div className={`${startOpen ? 'relative' : 'fixed bottom-4 right-4'} z-50`}>
      {isOpen ? (
        <Card className={`${startOpen ? 'w-full' : 'w-80'} h-96 flex flex-col p-4 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60`}>
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold">Sai's Personal Chat Bot</h3>
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
              ×
            </Button>
          </div>
          <div className="flex-1 overflow-auto space-y-4 scrollbar-thin scrollbar-thumb-primary scrollbar-track-transparent">
            {messages.length === 0 && (
              <div className="text-center text-muted-foreground p-4">
                👋 Hi! I'm Sai's chatbot. Feel free to ask me anything!
              </div>
            )}
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`rounded-lg px-4 py-2 max-w-[80%] animate-fade-in ${
                  msg.sender === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
          </div>
          <div className="flex gap-2 mt-4">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a message..."
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              className="flex-1"
            />
            <Button onClick={handleSend}>Send</Button>
          </div>
        </Card>
      ) : (
        <Button 
          size="icon" 
          className="h-12 w-12 rounded-full shadow-lg animate-bounce"
          onClick={() => setIsOpen(true)}
        >
          <MessageSquare />
        </Button>
      )}
    </div>
  );
};

export default ChatBot;