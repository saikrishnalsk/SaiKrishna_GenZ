import { Button } from "@/components/ui/button";
import { ArrowRight, Download } from "lucide-react";
import { Link } from "react-router-dom";

const Hero = () => {
  return (
    <div className="min-h-screen pt-20 flex items-center">
      <div className="container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <h1 className="text-5xl font-bold animate-fade-in">
            Hello!
            <br />
            I'm SAI KRISHNA
          </h1>
          <div className="space-y-2 animate-fade-in" style={{ animationDelay: "200ms" }}>
            <p className="text-xl text-muted-foreground">&lt;Coder&gt;</p>
            <p className="text-xl">Frontend Developer</p>
            <p className="text-xl">Focuses On Writing Clean Elegant & Efficient Code</p>
          </div>
          <p className="text-lg text-muted-foreground animate-fade-in" style={{ animationDelay: "400ms" }}>
            Working On 100 days MERN Stack Challenge To Level Up My Skill
          </p>
          <div className="flex gap-4 animate-fade-in" style={{ animationDelay: "600ms" }}>
            <Button asChild className="hover-scale">
              <Link to="/mern-challenge" className="group">
                100 Days MERN Stack Journey
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
            <Button variant="outline" className="hover-scale group">
              Download Resume
              <Download className="ml-2 h-4 w-4 transition-transform group-hover:translate-y-1" />
            </Button>
          </div>
        </div>
        <div className="relative">
          <div className="absolute inset-0 hero-gradient rounded-full blur-3xl opacity-20"></div>
          <img 
            src="/lovable-uploads/4f50d145-778d-4f7d-a555-e8a05bc4e229.png"
            alt="Sai Krishna"
            className="relative animate-float rounded-2xl"
          />
        </div>
      </div>
    </div>
  );
};

export default Hero;