import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Github, Linkedin, NotebookText } from "lucide-react";
import { Link, useParams } from "react-router-dom";

const DayDetails = () => {
  const { day } = useParams();
  
  return (
    <div className="container mx-auto py-8 px-4">
      <Button variant="outline" className="mb-6" asChild>
        <Link to="/mern-challenge">← Back to Challenge</Link>
      </Button>
      
      <Card className="glass-card animate-fade-in">
        <CardHeader>
          <CardTitle className="text-3xl">Day {day}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="prose dark:prose-invert max-w-none">
            <h2>What I Learned Today</h2>
            <p>
              Content for Day {day} will be added as you progress through your MERN stack journey.
            </p>
            
            <h2>Key Takeaways</h2>
            <ul>
              <li>Key point 1</li>
              <li>Key point 2</li>
              <li>Key point 3</li>
            </ul>
            
            <h2>Code Snippets</h2>
            <pre className="bg-muted p-4 rounded-lg">
              <code>
                // Your code snippets will go here
              </code>
            </pre>
          </div>
          
          <div className="flex gap-4 pt-4">
            <Button variant="outline" asChild>
              <a href="#" target="_blank" rel="noopener noreferrer">
                <Github className="mr-2 h-4 w-4" />
                View on GitHub
              </a>
            </Button>
            <Button variant="outline" asChild>
              <a href="#" target="_blank" rel="noopener noreferrer">
                <Linkedin className="mr-2 h-4 w-4" />
                LinkedIn Post
              </a>
            </Button>
            <Button variant="outline" asChild>
              <a href="#" target="_blank" rel="noopener noreferrer">
                <NotebookText className="mr-2 h-4 w-4" />
                Notion Notes
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DayDetails;