import { Card } from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import { ChartContainer, ChartLegend } from "@/components/ui/chart";
import { PieChart, Pie, Cell } from "recharts";
import { Copyright } from "lucide-react";

const About = () => {
  const skillsData = [
    { name: "Technical Skills", value: 70 },
    { name: "Networking", value: 30 }
  ];

  const COLORS = ["#6366f1", "#ec4899"];

  const chartConfig = {
    technicalSkills: {
      label: "Technical Skills",
      color: COLORS[0]
    },
    networking: {
      label: "Networking",
      color: COLORS[1]
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Section 1: Introduction */}
      <section className="py-12 px-6 mt-16 md:mt-20">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 animate-fade-in">
            <h2 className="text-2xl text-muted-foreground font-bold">about.</h2>
            <h1 className="text-4xl font-bold">Aspiring Frontend Developer</h1>
            <h2 className="text-3xl">MERN Stack</h2>
            <p className="text-xl text-muted-foreground">
              Working on 100 Days MERN Stack Challenge
            </p>
          </div>
          <div className="relative perspective-1000">
            <div 
              className="relative transform-gpu transition-all duration-500 hover:rotate-y-12 hover:scale-105"
              style={{
                transformStyle: 'preserve-3d',
                perspective: '1000px'
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/30 to-pink-500/30 rounded-lg filter blur-xl">
              </div>
              <img 
                src="/lovable-uploads/9ef208f5-5242-4396-9dc6-5907f1932a5c.png" 
                alt="Profile"
                className="relative w-48 h-48 object-cover mx-auto rounded-lg shadow-2xl"
                loading="eager"
                decoding="async"
                style={{
                  backfaceVisibility: 'hidden',
                  transform: 'translateZ(20px)'
                }}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: Skills with Pie Chart */}
      <section className="py-12 px-6 bg-muted/50">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h3 className="text-2xl font-semibold mb-6">Networking</h3>
                <ul className="space-y-3 text-lg">
                  <li className="flex items-center gap-2">
                    <span className="text-primary">•</span>
                    Community Management
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-primary">•</span>
                    Attending Meetups & Events
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-primary">•</span>
                    Networking with Like Minded People
                  </li>
                </ul>
              </div>
              <div className="space-y-4">
                <h3 className="text-2xl font-semibold mb-6">Technical Skills</h3>
                <ul className="space-y-3 text-lg">
                  <li className="flex items-center gap-2">
                    <span className="text-primary">•</span>
                    Frontend Developer
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-primary">•</span>
                    HTML/CSS
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-primary">•</span>
                    JavaScript
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-primary">•</span>
                    React
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="text-primary">•</span>
                    MERN Stack
                  </li>
                </ul>
              </div>
            </div>
            <div className="flex flex-col items-center justify-center p-8">
              <ChartContainer config={chartConfig} className="w-full max-w-lg">
                <PieChart width={400} height={400}>
                  <Pie
                    data={skillsData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {skillsData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                </PieChart>
              </ChartContainer>
              <div className="mt-8 flex gap-8">
                {skillsData.map((entry, index) => (
                  <div key={entry.name} className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: COLORS[index] }}
                    />
                    <span>{entry.name} ({entry.value}%)</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 3: Random Facts */}
      <section className="py-12 px-6">
        <div className="max-w-7xl mx-auto">
          <Card className="p-8 glass-card">
            <h3 className="text-2xl font-semibold mb-6">Random Facts</h3>
            <ul className="space-y-4 text-lg">
              <li className="flex items-center gap-2">
                <span className="text-primary">→</span>
                I Drink Lot of Tea
              </li>
              <li className="flex items-center gap-2">
                <span className="text-primary">→</span>
                I'm Slightly Addicted to LinkedIn
              </li>
              <li className="flex items-center gap-2">
                <span className="text-primary">→</span>
                Networking Learnt Me Alot
              </li>
              <li className="flex items-center gap-2">
                <span className="text-primary">→</span>
                Love to Travel Single
              </li>
            </ul>
          </Card>
        </div>
      </section>

      {/* Copyright Footer */}
      <footer className="py-6 text-center text-muted-foreground">
        <div className="flex items-center justify-center gap-2">
          <Copyright className="w-4 h-4" />
          <span>Sai Krishna L 2025</span>
        </div>
      </footer>
    </div>
  );
};

export default About;