import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Github, Linkedin, NotebookText } from "lucide-react";
import { Link } from "react-router-dom";

const MernChallenge = () => {
  // Generate array of 100 days
  const days = Array.from({ length: 100 }, (_, i) => i + 1);

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-4xl font-bold text-center mb-8 animate-fade-in">
        100 Days of MERN Stack Challenge
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {days.map((day) => (
          <Card key={day} className="glass-card hover-scale">
            <CardHeader>
              <CardTitle>Day {day}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Journey through the MERN stack - Day {day}
              </p>
              <div className="flex justify-between items-center">
                <div className="flex gap-2">
                  <Button variant="ghost" size="icon" asChild>
                    <a href="#" target="_blank" rel="noopener noreferrer">
                      <Github className="h-5 w-5" />
                    </a>
                  </Button>
                  <Button variant="ghost" size="icon" asChild>
                    <a href="#" target="_blank" rel="noopener noreferrer">
                      <Linkedin className="h-5 w-5" />
                    </a>
                  </Button>
                  <Button variant="ghost" size="icon" asChild>
                    <a href="#" target="_blank" rel="noopener noreferrer">
                      <NotebookText className="h-5 w-5" />
                    </a>
                  </Button>
                </div>
                <Button asChild>
                  <Link to={`/mern-challenge/day/${day}`}>Read More</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default MernChallenge;