import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Twitter, Linkedin, Mail, MessageSquare, Copyright } from "lucide-react";

const Contact = () => {
  const socialLinks = [
    {
      name: "Twitter @ X",
      icon: <Twitter className="w-5 h-5" />,
      href: "#",
      className: "bg-black hover:bg-gray-800"
    },
    {
      name: "LinkedIn",
      icon: <Linkedin className="w-5 h-5" />,
      href: "#",
      className: "bg-blue-600 hover:bg-blue-700"
    },
    {
      name: "Gmail",
      icon: <Mail className="w-5 h-5" />,
      href: "mailto:your.email@gmail.com",
      className: "bg-red-600 hover:bg-red-700"
    },
    {
      name: "Message",
      icon: <MessageSquare className="w-5 h-5" />,
      href: "#",
      className: "bg-green-600 hover:bg-green-700"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 sm:px-6">
        {/* Added pt-24 for navbar spacing */}
        <div className="pt-24 pb-12">
          <h1 className="text-3xl sm:text-4xl font-bold mb-12">Contact.</h1>
          
          <div className="max-w-md mx-auto">
            <Card className="p-6 sm:p-8 glass-card">
              <div className="grid gap-4">
                {socialLinks.map((link, index) => (
                  <a
                    key={index}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="no-underline"
                  >
                    <Button
                      className={`w-full justify-start gap-4 text-white ${link.className}`}
                    >
                      {link.icon}
                      {link.name}
                    </Button>
                  </a>
                ))}
                
                <Button
                  className="w-full justify-start gap-4 bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={() => window.open("#", "_blank")}
                >
                  <MessageSquare className="w-5 h-5" />
                  Join My Community
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </main>

      <footer className="py-6 text-center text-muted-foreground">
        <div className="flex items-center justify-center gap-2">
          <Copyright className="w-4 h-4" />
          <span>Sai Krishna L 2025</span>
        </div>
      </footer>
    </div>
  );
};

export default Contact;