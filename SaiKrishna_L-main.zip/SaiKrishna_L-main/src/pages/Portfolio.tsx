import Navbar from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Copyright } from "lucide-react";

const Portfolio = () => {
  const projects = [
    {
      title: "Personal Portfolio",
      image: "/placeholder.svg",
      description: "My personal portfolio website built with React and Tailwind CSS"
    },
    {
      title: "SpaceX Clone",
      image: "/placeholder.svg",
      description: "A clone of the SpaceX website using modern web technologies"
    },
    {
      title: "Text To Speech",
      image: "/placeholder.svg",
      description: "A text to speech application using Web Speech API"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="container mx-auto px-4 sm:px-6">
        {/* Added pt-24 for navbar spacing */}
        <div className="pt-24 pb-12">
          <h1 className="text-3xl sm:text-4xl font-bold mb-12">Portfolio</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <CardHeader className="p-0">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-48 object-cover"
                  />
                </CardHeader>
                <CardContent className="p-6">
                  <CardTitle className="mb-2">{project.title}</CardTitle>
                  <p className="text-muted-foreground">{project.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </main>

      <footer className="py-6 text-center text-muted-foreground">
        <div className="flex items-center justify-center gap-2">
          <Copyright className="w-4 h-4" />
          <span>Sai Krishna L 2025</span>
        </div>
      </footer>
    </div>
  );
};

export default Portfolio;