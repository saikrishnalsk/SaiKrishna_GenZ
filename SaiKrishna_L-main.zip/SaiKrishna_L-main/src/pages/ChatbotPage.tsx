import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import ChatBot from "@/components/ChatBot";

const ChatbotPage = () => {
  return (
    <div className="min-h-screen p-6">
      <div className="max-w-7xl mx-auto">
        <Button asChild variant="ghost" className="mb-6">
          <Link to="/" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>
        
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4 animate-fade-in">Chat with Sai's AI Assistant</h1>
          <p className="text-muted-foreground text-lg animate-fade-in" style={{ animationDelay: "200ms" }}>
            Feel free to ask me anything about web development, MERN stack, or my journey!
          </p>
        </div>

        <div className="flex justify-center items-center">
          <div className="w-full max-w-2xl">
            <ChatBot startOpen={true} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatbotPage;